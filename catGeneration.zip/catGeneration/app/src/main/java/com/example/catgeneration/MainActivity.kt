package com.example.catgeneration

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import java.io.FileOutputStream

// IMPORTANT:
// To change cat size: change scaledWidth and scaledHeight in CatView class
// right now catBase and catPat pull from the same array of colors
//      if they select the same color it will seem like no pattern is present
// colors can be added by defining new colors in onCreate and adding them to the
//      proper colors array
class MainActivity : AppCompatActivity() {

    var mFrame: FrameLayout? = null

    var catBase: Bitmap? = null
    var catCollar: Bitmap? = null
    var catLine: Bitmap? = null
    var baseColor: Int? = null
    var patColor: Int? = null
    var collarColor: Int? = null

    var pat: Bitmap? = null

    var sym: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "Entered onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // random numbers for cat generation, rolling of numbers should be done before every generation
        var r1 = (0..9).random()
        var r2 = (0..9).random()
        var r3 = (0..5).random()
        var r4 = (0..5).random()
        var r5 = (0..2).random()

        mFrame = findViewById<FrameLayout>(R.id.frame)

        catBase = BitmapFactory.decodeResource(resources, R.drawable.catbase)
        catCollar = BitmapFactory.decodeResource(resources, R.drawable.catcollar)
        catLine = BitmapFactory.decodeResource(resources, R.drawable.catline)

        val pats = arrayOf(R.drawable.pat01, R.drawable.pat02, R.drawable.pat03, R.drawable.pat04, R.drawable.pat05,
            R.drawable.pat06, R.drawable.pat07, R.drawable.pat08, R.drawable.pat09, R.drawable.pat10)

        // getting pattern, pattern should be re-rolled before every generation
        pat = BitmapFactory.decodeResource(resources, pats?.get(r1))


        val syms = arrayOf(R.drawable.sym01, R.drawable.sym02, R.drawable.sym03, R.drawable.sym04, R.drawable.sym05,
            R.drawable.sym06, R.drawable.sym07, R.drawable.sym08, R.drawable.sym09, R.drawable.sym10)

        // getting symbol, symbol should be re-rolled before every cat generation
        sym = BitmapFactory.decodeResource(resources, syms?.get(r2))

        // setting up color options, if changing amounts of colors be sure to change r3, r4, and r5
        val black = Color.BLACK
        val gray = Color.GRAY
        val white = Color.WHITE
        val brown = Color.argb(1,150, 102, 59)
        val orange = Color.argb(1,255, 150, 56)
        val yellow = Color.argb(1, 252, 245, 141)
        val red = Color.RED
        val blue = Color.BLUE
        val green = Color.GREEN

        // possible base and pattern colors
        val catColors = arrayOf(black, gray, white, brown, orange, yellow)
        // possible collar colors
        val collarColors = arrayOf(red, blue, green)

        // getting colors, colors should be re-rolled before every generation
        baseColor = catColors?.get(r3)
        patColor = catColors?.get(r4)
        collarColor = collarColors?.get(r5)

        Log.i(TAG, "calling generate")
        generate()
    }

    fun generate() {
        Log.i(TAG, "generating")
        val catView = CatView(this)
        mFrame?.addView(catView)

    }

    inner class CatView internal constructor(context: Context) : View(context) {

        var scaledBase: Bitmap? = null
        var scaledCollar: Bitmap? = null
        var scaledLine: Bitmap? = null
        var scaledPat: Bitmap? = null
        var scaledSym: Bitmap? = null
        val mPainter = Paint()
        // cat position
        val xPos = 200f
        val yPos = 200f
        // change scaled width and height by multiplying/dividing BITMAP_WIDTH/HEIGHT by the same value
        var scaledWidth = BITMAP_WIDTH
        var scaledHeight = BITMAP_HEIGHT

        init {
            Log.i(TAG, "init CatView"+(pat is Bitmap).toString())
            mPainter.isAntiAlias = true
            createScaledBitmap()
        }

        fun createScaledBitmap() {

            this.scaledBase = Bitmap.createScaledBitmap(catBase!!, scaledWidth, scaledHeight, false)
            this.scaledCollar = Bitmap.createScaledBitmap(catCollar!!, scaledWidth, scaledHeight, false)
            this.scaledLine = Bitmap.createScaledBitmap(catLine!!, scaledWidth, scaledHeight, false)
            this.scaledPat = Bitmap.createScaledBitmap(pat!!, scaledWidth, scaledHeight, false)
            this.scaledSym = Bitmap.createScaledBitmap(sym!!, scaledWidth, scaledHeight, false)

        }

        @Synchronized
        override fun onDraw(canvas: Canvas) {
            Log.i(TAG, "onDraw")

            canvas.save()
            // change color
            var filter = baseColor?.let { LightingColorFilter(it, 1) }
            mPainter.colorFilter = filter
            canvas.drawBitmap(scaledBase!!, xPos, yPos, mPainter)
            canvas.restore()
            canvas.save()
            filter = collarColor?.let { LightingColorFilter(it, 1) }
            mPainter.colorFilter = filter
            canvas.drawBitmap(scaledCollar!!, xPos, yPos, mPainter)
            canvas.restore()
            canvas.save()
            filter = patColor?.let { LightingColorFilter(it, 1) }
            mPainter.colorFilter = filter
            canvas.drawBitmap(scaledPat!!, xPos, yPos, mPainter)
            canvas.restore()
            canvas.save()
            // remove colorFilter
            mPainter.reset()
            mPainter.isAntiAlias = true
            canvas.drawBitmap(scaledLine!!, xPos, yPos, mPainter)
            canvas.restore()
            canvas.save()
            canvas.drawBitmap(scaledSym!!, xPos, yPos, mPainter)
            canvas.restore()
        }

    }

    companion object {
        val BITMAP_HEIGHT = 250
        val BITMAP_WIDTH  = 185
        val TAG = "cat"
    }

}